import java.text.DecimalFormat;

public class Main {
    public static void main(String[] args) {

        String nomeProduto = "Tijolo";
        double valorUnitario = 3.50;
        int quantidadeComprada = 200;
        double taxaImposto = 0.15;
        double margemLucro = 0.30;

        double valorTotalSemImposto = valorUnitario * quantidadeComprada;
        double valorDoImposto = valorTotalSemImposto * taxaImposto;
        double valorTotalComImposto = valorTotalSemImposto + valorDoImposto;
        double precoVenda = valorTotalComImposto * (1 + margemLucro);

        DecimalFormat df = new DecimalFormat("R$ #,##0.00");
        String valorTotalComImpostoFormatado = df.format(valorTotalComImposto);
        String precoVendaFormatado = df.format(precoVenda);

        System.out.println("Nome do produto: " + nomeProduto);
        System.out.println("Preço unitário: R$ " + valorUnitario);
        System.out.println("Quantidade comprada: " + quantidadeComprada);
        System.out.println("Taxa de imposto: " + (taxaImposto * 100) + "%");
        System.out.println("Margem de lucro desejada: " + (margemLucro * 100) + "%");

        System.out.println("Valor total sem impostos: R$ " + valorTotalSemImposto);
        System.out.println("Valor do imposto sobre o total: R$ " + valorDoImposto);
        System.out.println("Valor total com impostos: " + valorTotalComImpostoFormatado);
        System.out.println("Preço de venda sugerido: " + precoVendaFormatado);

        String mensagemFinal = "Para o produto " + nomeProduto + ", o valor total com impostos é "
                + valorTotalComImpostoFormatado + " e o preço de venda sugerido é " + precoVendaFormatado + ".";

        System.out.println(mensagemFinal);
    }
}