import java.util.Scanner;




public class Main {
    public static void main(String[] args) {

       Scanner input = new Scanner(System.in);

        System.out.println("Digite seu login: ");
        String login = input.nextLine();

        System.out.println("Digite sua senha: ");
        String senha = input.nextLine();


        if(login.equals("admin") && senha.equals("000")){
            System.out.println("Login e senha corretos!");
        } else {
            System.out.println("Login ou senha incorretos!");
        }


       input.close();


      }

    }