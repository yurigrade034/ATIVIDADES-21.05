import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Digite o primeiro número: ");
        double num1 = input.nextDouble();

        System.out.print("Digite o segundo número: ");
        double num2 = input.nextDouble();

        System.out.print("Escolha a operação (+, -, *, /): ");
        String operacao = input.next();

        double resultado = 0;
        boolean valido = true;

        if (operacao.equals("+")) {
            resultado = num1 + num2;
        } else if (operacao.equals("-")) {
            resultado = num1 - num2;
        } else if (operacao.equals("*")) {
            resultado = num1 * num2;
        } else if (operacao.equals("/")) {
            if (num2 != 0) {
                resultado = num1 / num2;
            } else {
                System.out.println("Erro: divisao por zero");
                valido = false;
            }
        } else {
            System.out.println("Operação invalida");
            valido = false;
        }

        if (valido) {
            System.out.println("Resultado: " + resultado);
        }

        input.close();
    }
}
