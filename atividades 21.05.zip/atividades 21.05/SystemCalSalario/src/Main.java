import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);


        System.out.print("Digite o salário bruto: R$ ");
        double salarioBruto = input.nextDouble();

        System.out.print("Digite os anos trabalhados: ");
        int anos = input.nextInt();


        double bonus = 0;
        if (anos > 10) {
            bonus = salarioBruto * 0.10;
        } else if (anos >= 5) {
            bonus = salarioBruto * 0.05;
        }


        double imposto = 0;
        if (salarioBruto > 5000) {
            imposto = salarioBruto * 0.27;
        } else if (salarioBruto >= 3000) {
            imposto = salarioBruto * 0.18;
        } else {
            imposto = salarioBruto * 0.10;
        }


        double salarioLiquido = (salarioBruto + bonus) - imposto;


        System.out.println("Salário Bruto: R$ " + salarioBruto);
        System.out.println("Bônus Recebido: R$ " + bonus);
        System.out.println("Imposto Descontado: R$ " + imposto);
        System.out.println("Salário Líquido: R$ " + salarioLiquido);

        input.close();
    }
}
