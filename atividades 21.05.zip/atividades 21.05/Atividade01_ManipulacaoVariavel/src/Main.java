public class Main {
    public static void main(String[] args) {



        int idadePessoa = 18;
        int idadePessoa2 = 19;
        double alturaPessoa = 1.75;
        String nomePessoa = "Yuri";
        boolean estudadePessoa = true;



        System.out.println("Sua idade é " + idadePessoa);
        System.out.println("Sua altura é "  + alturaPessoa);
        System.out.println("Seu nome é " + nomePessoa);
        System.out.println("É estudante ? " + estudadePessoa);

        double resultadoIdade = idadePessoa + idadePessoa2;
        System.out.println("Idade somadas: " + resultadoIdade);

        double resultadoAltura = alturaPessoa * 2;
        System.out.println("A soma da altura: " + resultadoAltura + " metros");

        String saudacaoPessoa = "saudaçoes fera, seja bem vindo " + nomePessoa;;
        System.out.println(saudacaoPessoa);



    }

}
