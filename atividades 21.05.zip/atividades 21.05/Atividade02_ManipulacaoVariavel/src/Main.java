
public class Main {
    public static void main(String[] args) {

        String nomePessoa = "Yuri";
        int idadePessoa = 18;
        double salarioMensal = 2300.00;
        int mesesTrabalhados = 11;
        int quantidadeProdutosComprados = 20;
        double valorTotalCompras = 800.00;


        double salarioAnualBruto = salarioMensal * mesesTrabalhados;
        double salarioAnualLiquido = salarioAnualBruto - 2000.00;
        double mediaValorProduto = valorTotalCompras / quantidadeProdutosComprados;

        String msgPersonalizada = "Olá, " + nomePessoa + ", seu salário anual líquido é R$ " + salarioAnualLiquido;

        System.out.println("Seu nome é " + nomePessoa);
        System.out.println("Sua idade é " + idadePessoa);
        System.out.println("Seu salário bruto anual é R$ " + salarioAnualBruto);
        System.out.println("Você trabalhou " + mesesTrabalhados + " meses");
        System.out.println("Você comprou " + quantidadeProdutosComprados + " produtos");
        System.out.println("Valor total gasto com compras: R$ " + valorTotalCompras);
        System.out.println("A média gasta com os produtos foi R$ " + mediaValorProduto);
        System.out.println(msgPersonalizada);

    }
}