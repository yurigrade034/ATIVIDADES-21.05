import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Digite um número: ");
        double numero = input.nextDouble();

        if (numero > 0) {
            System.out.println("Número Positivo");
        } else if (numero < 0) {
            System.out.println("Número Negativo");
        } else {
            System.out.println("Zero");
        }

        input.close();
    }
}
